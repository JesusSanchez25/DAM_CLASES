package exception;

public class LibroException extends Exception{

    public LibroException(String message) {
        super(message);
    }
}
