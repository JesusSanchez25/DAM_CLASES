package ejercicioCompras.model;


import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class Usuario {

    private String usuario,contrasenia,correo;




}
