package model;

public interface Reparable {

    void reparar();

}
